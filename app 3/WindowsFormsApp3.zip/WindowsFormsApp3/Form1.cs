﻿using System;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {

        private const int listenPort = 9500;
        private const int listenerPort = 11111;
        public int timeInterval;

        public static async Task StartListener()
        {
            UdpClient listener = new UdpClient(listenPort);
            IPEndPoint groupEP = new IPEndPoint(IPAddress.Any, listenPort);
            Socket s = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            IPAddress broadcast = IPAddress.Parse("192.168.1.255");
            IPEndPoint ep = new IPEndPoint(broadcast, 11000);

            try
            {
                while (true)
                {
                    byte[] bytes = listener.Receive(ref groupEP);
                    string sendStr = ($"{Encoding.ASCII.GetString(bytes, 0, bytes.Length)}");
                    await Task.Delay(1);
                    byte[] sendbuf = Encoding.ASCII.GetBytes(sendStr);
                    s.SendTo(sendbuf, ep);
                    Console.WriteLine("Message sent to the broadcast address");
                    Console.WriteLine($"Received broadcast from {groupEP} :");
                }
            }
            catch (SocketException e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                listener.Close();
            }
        }

        public static async Task ReceiveFromClient()
        {
            UdpClient udpClient = new UdpClient(listenerPort);
            IPEndPoint remoteEP = new IPEndPoint(IPAddress.Any, listenerPort);
            Socket s2 = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            IPAddress sendBack = IPAddress.Parse("192.168.56.1");
            IPEndPoint serverEP = new IPEndPoint(sendBack, 9551);
            try
            {
                while (true)
                {
                    byte[] bytes = udpClient.Receive(ref remoteEP);
                    await Task.Delay(1);
                    string sendStr = ($"{Encoding.ASCII.GetString(bytes, 0, bytes.Length)}");
                    await Task.Delay(1);
                    byte[] sendbuf = Encoding.ASCII.GetBytes(sendStr);
                    
                    if (checkBox1.Checked)
                    {
                        await Task.Delay(timeInterval);
                        s2.SendTo(sendbuf, serverEP);

                    }
                    else
                    {
                        s2.SendTo(sendbuf, serverEP);
                    }
                    //s2.SendTo(sendbuf, serverEP);
                    //Console.WriteLine("Message sent to the broadcast address");
                    //Console.WriteLine($"Received broadcast from {remoteEP} :");
                }
            }
            catch (SocketException e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                udpClient.Close();

            }
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void checkBox1_Click(object sender, System.EventArgs e)
        {
            //// The CheckBox control's Text property is changed each time the
            //// control is clicked, indicating a checked or unchecked state.  
            //if (checkBox1.Checked)
            //{
            //    //_ = Task.Run(() => ReceiveFromClient());
            //    //_ = Task.Run(() => StartListener());

            //}
            //else
            //{
            //    checkBox1.Text = "Unchecked";
            //}
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            

        }

        public void getDelay() 
        {
           
          timeInterval = Int32.Parse(textBox2.Text);

        }


    }
}
